﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Group1_CSP
{
    class ProgOps
    {
        //----------------------------------------------------------------------------------------------------
        //Variables and objects

        //Connection string
        private const string CONNECT_STRING = @"Server = cstnt.tstc.edu; Database = inew2330fa20; User Id = group1bfa202330; Password = 1237895";
        //Connection
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);

        //Objects for Customers table
        private static SqlCommand _sqlCustomersCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daCustomers = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtCustomersTable = new DataTable(); //Data table

        //Objects for Managers table
        private static SqlCommand _sqlManagersCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daManagers = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtManagersTable = new DataTable(); //Data table

        //Objects for Employees table
        private static SqlCommand _sqlEmployeesCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daEmployees = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtEmployeesTable = new DataTable(); //Data table

        //Objects for Products table
        private static SqlCommand _sqlProductsCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daProducts = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtProductsTable = new DataTable(); //Data table

        //Objects for Orders table
        private static SqlCommand _sqlOrdersCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daOrders = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtOrdersTable = new DataTable(); //Data table

        //----------------------------------------------------------------------------------------------------
        //Getters

        //Getter for Customers table
        public static DataTable CustomersTable
        {
            get { return _dtCustomersTable; }
        }

        //Getter for Managers table
        public static DataTable ManagersTable
        {
            get { return _dtManagersTable; }
        }

        //Getter for Employees table
        public static DataTable EmployeesTable
        {
            get { return _dtEmployeesTable; }
        }

        //Getter for Products table
        public static DataTable ProductsTable
        {
            get { return _dtProductsTable; }
        }

        //Getter for Orders table
        public static DataTable OrdersTable
        {
            get { return _dtOrdersTable; }
        }

        //----------------------------------------------------------------------------------------------------
        //Open and close functions

        //Opens database connection
        public static void OpenDatabase()
        {
            //Opens database
            _cntDatabase.Open();
            //Tells user they have connected to the database successfully
            MessageBox.Show("Connection successful.", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //Closes database and disposes of objects
        public static void CloseDatabase()
        {
            //Closes database
            _cntDatabase.Close();
            //Tells user they have connected to the database successfully
            MessageBox.Show("Closed successfully.", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Disposes Customer objects
            _sqlCustomersCommand.Dispose(); //Disposes command object
            _daCustomers.Dispose(); //Disposes data adapter
            _dtCustomersTable.Dispose(); //Disposes data table

            //Disposes Managers objects
            _sqlManagersCommand.Dispose(); //Disposes command object
            _daManagers.Dispose(); //Disposes data adapter
            _dtManagersTable.Dispose(); //Disposes data table

            //Disposes Employees objects
            _sqlEmployeesCommand.Dispose(); //Disposes command object
            _daEmployees.Dispose(); //Disposes data adapter
            _dtEmployeesTable.Dispose(); //Disposes data table

            //Disposes Products objects
            _sqlProductsCommand.Dispose(); //Disposes command object
            _daProducts.Dispose(); //Disposes data adapter
            _dtProductsTable.Dispose(); //Disposes data table

            //Disposes Orders objects
            _sqlOrdersCommand.Dispose(); //Disposes command object
            _daOrders.Dispose(); //Disposes data adapter
            _dtOrdersTable.Dispose(); //Disposes data table
        }

        //----------------------------------------------------------------------------------------------------
        //Add any functions needed

        //Ian Fuller - Get logins from Managers table
        public static void ManagersLogin(string username, string password)
        {

        }

        //Ian Fuller - Managers command
        public static void ManagersDatabaseCommand(DataGridView dgvManagersView)
        {
            //String contains query
            string query = "SELECT * FROM group1bfa202330.Employees";

            //Establish objects
            _sqlManagersCommand = new SqlCommand(query, _cntDatabase); //Command object
            _daManagers.SelectCommand = _sqlManagersCommand; //Data adapter
            _daManagers.Fill(_dtManagersTable); //Fill table

            //Bind controls to datatable
            dgvManagersView.DataSource = _dtManagersTable;
        }
    }
}
